var searchData=
[
  ['bodypartcnn',['BodyPartCNN',['../class_body_part_c_n_n.html#aa93c47e88781c39dafe807f590798818',1,'BodyPartCNN::BodyPartCNN()'],['../class_body_part_c_n_n.html#a70a8627695821b321dedb00b9b45f9c0',1,'BodyPartCNN::BodyPartCNN(const string &amp;model_file, const string &amp;trained_file)']]],
  ['boolattribute',['BoolAttribute',['../classtinyxml2_1_1_x_m_l_element.html#a34811e4d1881e4ecc95c49f0f3799115',1,'tinyxml2::XMLElement']]],
  ['boolvalue',['BoolValue',['../classtinyxml2_1_1_x_m_l_attribute.html#afb444b7a12527f836aa161b54b2f7ce7',1,'tinyxml2::XMLAttribute']]]
];
