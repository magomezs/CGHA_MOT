var searchData=
[
  ['needs_5fentity_5fprocessing',['NEEDS_ENTITY_PROCESSING',['../classtinyxml2_1_1_str_pair.html#a0301ef962e15dd94574431f1c61266c5a4f1e01a55f8efe4ca72c32d454060237',1,'tinyxml2::StrPair']]],
  ['needs_5fnewline_5fnormalization',['NEEDS_NEWLINE_NORMALIZATION',['../classtinyxml2_1_1_str_pair.html#a0301ef962e15dd94574431f1c61266c5a8f2045d56e70745d718672c0da91d0e0',1,'tinyxml2::StrPair']]],
  ['needs_5fwhitespace_5fcollapsing',['NEEDS_WHITESPACE_COLLAPSING',['../classtinyxml2_1_1_str_pair.html#a0301ef962e15dd94574431f1c61266c5a13996e9d4ed18fd2d6af59bbab291b63',1,'tinyxml2::StrPair']]]
];
