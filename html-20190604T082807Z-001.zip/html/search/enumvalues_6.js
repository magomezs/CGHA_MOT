var searchData=
[
  ['warp_5fmode_5faffine',['WARP_MODE_AFFINE',['../ecc_8h.html#aa952b7893ff7410c97554c365ba8a490a00747061f1b30275e4287bd0efade343',1,'ecc.h']]],
  ['warp_5fmode_5feuclidean',['WARP_MODE_EUCLIDEAN',['../ecc_8h.html#aa952b7893ff7410c97554c365ba8a490a0d16a4c409c6e02d7afe068cb121377d',1,'ecc.h']]],
  ['warp_5fmode_5fhomography',['WARP_MODE_HOMOGRAPHY',['../ecc_8h.html#aa952b7893ff7410c97554c365ba8a490a959f4dad7bf059fa90d594cff7f29045',1,'ecc.h']]],
  ['warp_5fmode_5ftranslation',['WARP_MODE_TRANSLATION',['../ecc_8h.html#aa952b7893ff7410c97554c365ba8a490a7cea3d90c1b22be4d615c19bd323ce29',1,'ecc.h']]]
];
