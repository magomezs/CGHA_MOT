var searchData=
[
  ['videomanagement',['VideoManagement',['../namespace_video_management.html',1,'']]]
];
