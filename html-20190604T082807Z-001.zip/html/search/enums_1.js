var searchData=
[
  ['xmlerror',['XMLError',['../namespacetinyxml2.html#a1fbf88509c3ac88c09117b1947414e08',1,'tinyxml2']]]
];
