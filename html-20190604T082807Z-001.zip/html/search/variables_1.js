var searchData=
[
  ['age',['age',['../struct_agent.html#a6da1e3e5d0caa66081150696af7a54ca',1,'Agent']]],
  ['ankle_5fl',['ankle_l',['../struct_joints.html#a31e32cd11f31da305e6a6b1dc7bcafda',1,'Joints']]],
  ['ankle_5fl_5fdetected',['ankle_l_detected',['../struct_joints.html#adaa24cb1648585372eb9e7bca8a2ab1b',1,'Joints']]],
  ['ankle_5fr',['ankle_r',['../struct_joints.html#af7b0269ed39bbb079d4b3e6141105dd9',1,'Joints']]],
  ['ankle_5fr_5fdetected',['ankle_r_detected',['../struct_joints.html#a7f2e02675e2fc572fdb47b2d4c04ccf2',1,'Joints']]]
];
