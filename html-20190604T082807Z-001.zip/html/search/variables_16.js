var searchData=
[
  ['waist',['waist',['../struct_joints.html#ad14c3fa995754603996d34208af506e3',1,'Joints']]],
  ['waist_5fdetected',['waist_detected',['../struct_joints.html#a0decbf5543e8e3f8656805d485a831ad',1,'Joints']]],
  ['wrist_5fl',['wrist_l',['../struct_joints.html#aebe28231871c9e03f16a3ae2491a2dff',1,'Joints']]],
  ['wrist_5fl_5fdetected',['wrist_l_detected',['../struct_joints.html#a321e69018a6a18766164b2b588748b96',1,'Joints']]],
  ['wrist_5fr',['wrist_r',['../struct_joints.html#a61a8b129c4165ebb114a69a4cfc1649e',1,'Joints']]],
  ['wrist_5fr_5fdetected',['wrist_r_detected',['../struct_joints.html#adb136112ae2f69247f03a2c60a4502ce',1,'Joints']]]
];
