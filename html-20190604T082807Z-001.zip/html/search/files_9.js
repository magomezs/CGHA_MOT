var searchData=
[
  ['video_5fmanagement_2ecpp',['video_management.cpp',['../video__management_8cpp.html',1,'']]],
  ['video_5fmanagement_2eh',['video_management.h',['../video__management_8h.html',1,'']]]
];
