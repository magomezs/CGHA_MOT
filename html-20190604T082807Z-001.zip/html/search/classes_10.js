var searchData=
[
  ['upperdetector',['UpperDetector',['../class_upper_detector.html',1,'']]]
];
