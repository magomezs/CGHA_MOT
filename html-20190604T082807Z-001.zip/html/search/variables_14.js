var searchData=
[
  ['u_5farea',['U_AREA',['../class_evaluation.html#a4d31d7021b7643b269fb0b4ba24519d0',1,'Evaluation']]],
  ['ula',['ula',['../struct_limbs.html#aa6892c86b4c8989cd4e27b08b69cb50c',1,'Limbs']]],
  ['ula_5fdetected',['ula_detected',['../struct_limbs.html#a7f4f567de8eddac3714118ec9d1200b9',1,'Limbs']]],
  ['ula_5froi',['ula_roi',['../struct_limbs.html#a92613a91d503719fa59be54ca6688a80',1,'Limbs']]],
  ['ull',['ull',['../struct_limbs.html#a75cd901c6623e9f562343da47e2fcbd4',1,'Limbs']]],
  ['ull_5fdetected',['ull_detected',['../struct_limbs.html#afcb9bb7db2bda68e70a0e517cc6c5df8',1,'Limbs']]],
  ['ull_5froi',['ull_roi',['../struct_limbs.html#a491367356b0675374d3dad80967913fa',1,'Limbs']]],
  ['upper_5fbody',['upper_body',['../class_upper_detector.html#a1b11914c554f90a60ce735e44b2b67d0',1,'UpperDetector']]],
  ['ura',['ura',['../struct_limbs.html#a62245f41d14bd83d0aa88bdb46cd5686',1,'Limbs']]],
  ['ura_5fdetected',['ura_detected',['../struct_limbs.html#a7a2e11b4dbefb679b29a0d0abc5c5298',1,'Limbs']]],
  ['ura_5froi',['ura_roi',['../struct_limbs.html#a74312a723069441a9c97211156572373',1,'Limbs']]],
  ['url',['url',['../struct_limbs.html#ac1ccf7316c7d74386b1ee3825f874d86',1,'Limbs']]],
  ['url_5fdetected',['url_detected',['../struct_limbs.html#a26ae13299c3569e88a734a78ec020455',1,'Limbs']]],
  ['url_5froi',['url_roi',['../struct_limbs.html#a1761d4c07cd54b2215d85bd2e3879834',1,'Limbs']]]
];
