var searchData=
[
  ['open',['OPEN',['../classtinyxml2_1_1_x_m_l_element.html#a07a6ce25c17aaa505933db57f2373e50a78cf277c55b4655c86458dfecb11d349',1,'tinyxml2::XMLElement']]]
];
