var searchData=
[
  ['preserve_5fwhitespace',['PRESERVE_WHITESPACE',['../namespacetinyxml2.html#a7f91d00f77360f850fd5da0861e27dd5a751769aa625fe5fe5286e9779edec56a',1,'tinyxml2']]]
];
