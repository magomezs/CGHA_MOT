var searchData=
[
  ['readbom',['ReadBOM',['../classtinyxml2_1_1_x_m_l_util.html#ae9bcb2bc3cd6475fdc644c8c17790555',1,'tinyxml2::XMLUtil']]],
  ['reca',['reca',['../class_evaluation.html#a892a3544f398885771ef9fec2411e421',1,'Evaluation']]],
  ['recall',['recall',['../class_evaluation.html#acf7bf45d1f53d4d6be4327d67568618e',1,'Evaluation']]],
  ['rect2bodyroi',['Rect2BodyRoi',['../detection_8cpp.html#ac55a54fe777c31e8937aa454c0c2eb0b',1,'detection.cpp']]],
  ['rect2bodyroy',['Rect2BodyRoy',['../namespacedop.html#aabf112a3c4061042db4cff264402dfde',1,'dop']]],
  ['rect2headroi',['Rect2HeadRoi',['../detection_8cpp.html#a390ea31184badd4fb9a2b79504aaca7b',1,'detection.cpp']]],
  ['rectanglecenter',['rectangleCenter',['../namespace_r_o_is.html#a843f7ff1afdc07f257611a5556898fbf',1,'ROIs']]],
  ['reference',['Reference',['../struct_reference.html',1,'Reference'],['../struct_agent.html#a1d0b4e86f6ce4e6cd4fe785e059efa67',1,'Agent::reference()']]],
  ['remove_5fagent',['remove_agent',['../namespace_agent_management.html#a319405c776896e8c19aa6b44bb6ded0e',1,'AgentManagement']]],
  ['renders_5fassigment',['renders_assigment',['../namespace_association.html#a6ceb2365629fb2a8516fa6721b66feab',1,'Association']]],
  ['replace_5finfinites',['replace_infinites',['../class_munkres.html#a9248629fc0180a8299333e7721d7d6ad',1,'Munkres']]],
  ['resize',['resize',['../class_matrix.html#a61cc9e991bbc443da6644265808116c5',1,'Matrix']]],
  ['right',['right',['../struct_interface_1_1_mouse_click.html#a0205028e5c576368206f850e8cc11bdd',1,'Interface::MouseClick']]],
  ['rnet',['rnet',['../class_m_s___d_o_a_s.html#af5ec12f5f0b27085ea5f424677c65f07',1,'MS_DOAS']]],
  ['rois',['ROIs',['../namespace_r_o_is.html',1,'']]],
  ['rois_2ecpp',['rois.cpp',['../rois_8cpp.html',1,'']]],
  ['rois_2eh',['rois.h',['../rois_8h.html',1,'']]],
  ['rootelement',['RootElement',['../classtinyxml2_1_1_x_m_l_document.html#ad2b70320d3c2a071c2f36928edff3e1c',1,'tinyxml2::XMLDocument::RootElement()'],['../classtinyxml2_1_1_x_m_l_document.html#a23a25b573d2adf3ee6075636c2a31c73',1,'tinyxml2::XMLDocument::RootElement() const ']]],
  ['rows',['rows',['../class_matrix.html#a0954c8de3cd2695f3c2f55ef21cc7786',1,'Matrix']]]
];
