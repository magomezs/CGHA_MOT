var searchData=
[
  ['whitespacemode',['WhitespaceMode',['../classtinyxml2_1_1_x_m_l_document.html#a94b3ea2f77c9ac831723984df5a02d01',1,'tinyxml2::XMLDocument']]]
];
