var searchData=
[
  ['descriptors_2ecpp',['descriptors.cpp',['../descriptors_8cpp.html',1,'']]],
  ['descriptors_2eh',['descriptors.h',['../descriptors_8h.html',1,'']]],
  ['detection_2ecpp',['detection.cpp',['../detection_8cpp.html',1,'']]],
  ['detection_2eh',['detection.h',['../detection_8h.html',1,'']]]
];
