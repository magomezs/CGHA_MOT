var searchData=
[
  ['gt',['gt',['../class_evaluation.html#a53c288abd1b7300ebc7f7ee3ded342a0',1,'Evaluation::gt()'],['../class_evaluation.html#a615bab952a3d328cb19087ef461a4421',1,'Evaluation::GT()']]]
];
