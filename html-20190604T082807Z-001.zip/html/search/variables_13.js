var searchData=
[
  ['tn',['tn',['../class_evaluation.html#a4941fb181db32af7885317bcf06e3172',1,'Evaluation']]],
  ['total_5ffp',['total_fp',['../class_evaluation.html#a15de40b14063251a9556bcb5ea65ed99',1,'Evaluation']]],
  ['total_5fgt',['total_gt',['../class_evaluation.html#a85693d2a01c08a1b31c9a96ee077842d',1,'Evaluation']]],
  ['total_5fi_5farea',['total_i_area',['../class_evaluation.html#ae6bc9f4de9eb24b64bb1aa084e73bb06',1,'Evaluation']]],
  ['total_5fmiss',['total_miss',['../class_evaluation.html#aa017c5808cd095862c712065a78abf59',1,'Evaluation']]],
  ['total_5fmm',['total_mm',['../class_evaluation.html#a1a4079e1d92c1c2aecd39dc6e132a5f6',1,'Evaluation']]],
  ['total_5fu_5farea',['total_u_area',['../class_evaluation.html#a6315b94a5f5553a5f013af094ce9fe16',1,'Evaluation']]],
  ['tp',['tp',['../class_evaluation.html#ad87dd807caa0e2274402ac0c686b07f9',1,'Evaluation']]],
  ['track',['track',['../struct_agent.html#af53fdbb447ba8d87d70126a25722d62d',1,'Agent']]]
];
