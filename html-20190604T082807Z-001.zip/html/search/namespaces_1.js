var searchData=
[
  ['distancemetric',['DistanceMetric',['../namespace_distance_metric.html',1,'']]],
  ['dop',['dop',['../namespacedop.html',1,'']]]
];
