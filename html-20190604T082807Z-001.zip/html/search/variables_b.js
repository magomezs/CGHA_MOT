var searchData=
[
  ['knee_5fl',['knee_l',['../struct_joints.html#adceec84670de6ddcbc1f07c37dccba53',1,'Joints']]],
  ['knee_5fl_5fdetected',['knee_l_detected',['../struct_joints.html#a5ff720c4c09532cbbaf7543573cdc5bb',1,'Joints']]],
  ['knee_5fr',['knee_r',['../struct_joints.html#a9a8d7d44364dd77c8f3db7942b006b63',1,'Joints']]],
  ['knee_5fr_5fdetected',['knee_r_detected',['../struct_joints.html#a59a788cfffa395f9677fc2ee9dcdf909',1,'Joints']]]
];
