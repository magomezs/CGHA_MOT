var searchData=
[
  ['shoulder_5fl',['shoulder_l',['../struct_joints.html#aa3a978b47bcdb549e2cfde9b51dba06c',1,'Joints']]],
  ['shoulder_5fl_5fdetected',['shoulder_l_detected',['../struct_joints.html#a3647828649a66f9cd56fdbc8448856a5',1,'Joints']]],
  ['shoulder_5fr',['shoulder_r',['../struct_joints.html#a445ae4a5d844173fa0619459d509a62d',1,'Joints']]],
  ['shoulder_5fr_5fdetected',['shoulder_r_detected',['../struct_joints.html#abe22692813d76d5c979d899f4ac010e1',1,'Joints']]],
  ['sizes',['sizes',['../class_c_p_m.html#a38b6866d443fec5d22f1496a04fe1d16',1,'CPM']]],
  ['svm',['svm',['../class_h_c_s_s___d_o_a_s.html#a6706dbf28a586dcd28a977bb7ad8e49f',1,'HCSS_DOAS']]]
];
