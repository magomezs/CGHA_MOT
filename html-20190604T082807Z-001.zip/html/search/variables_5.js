var searchData=
[
  ['elbow_5fl',['elbow_l',['../struct_joints.html#a69d7f7d417a5851eca6e85793b9b68b9',1,'Joints']]],
  ['elbow_5fl_5fdetected',['elbow_l_detected',['../struct_joints.html#a91b6779943019313368abbdee7bf0178',1,'Joints']]],
  ['elbow_5fr',['elbow_r',['../struct_joints.html#a642274daf7938fa5740e79b04fb46c1b',1,'Joints']]],
  ['elbow_5fr_5fdetected',['elbow_r_detected',['../struct_joints.html#a886b7fd58c81596e8c31140a5ee7c8c1',1,'Joints']]],
  ['estimator',['estimator',['../struct_agent.html#a95538e04113835e4052587ad4709ba65',1,'Agent']]]
];
