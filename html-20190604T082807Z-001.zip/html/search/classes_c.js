var searchData=
[
  ['perfectdetection',['PerfectDetection',['../class_perfect_detection.html',1,'']]],
  ['person',['Person',['../struct_person.html',1,'']]]
];
