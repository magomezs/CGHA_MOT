var searchData=
[
  ['neck',['neck',['../struct_joints.html#acb43724ae863cffae35f882743e44896',1,'Joints']]],
  ['neck_5fdetected',['neck_detected',['../struct_joints.html#a39c17241cbce51fbb0c80acdfae47c6d',1,'Joints']]],
  ['net',['net',['../class_s_s___d_o_a_s.html#aa02380bc3d7dbb6ed06daaf287ea6dfe',1,'SS_DOAS::net()'],['../class_m_s___d_o_a_s.html#a4e96d5b8ff53d4be7f7d88c9549addf5',1,'MS_DOAS::net()']]]
];
