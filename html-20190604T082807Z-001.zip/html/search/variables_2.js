var searchData=
[
  ['body_5flocation',['body_location',['../struct_person.html#a4d429cf087699b9d157900a44e132429',1,'Person']]],
  ['body_5froi',['body_roi',['../struct_person.html#aef488d2d086642939678c76e676fc77f',1,'Person']]],
  ['bodydetector',['bodyDetector',['../class_head_body_fusion.html#a351c7bb49c5117e5eb275be8905c4a09',1,'HeadBodyFusion']]]
];
